<nav>
<h2>Menu</h2>
<ul>
<li><a href="../index.php">Principal</a></li>
<li><a href="./destaques.php">Destaques</a></li>
<li><a href="./programacao.php">Programacao</a></li>
<li><a href="./fotos.php">Fotos</a></li>
<li><a href="./contato.php">contato</a></li>
</ul>
</nav>